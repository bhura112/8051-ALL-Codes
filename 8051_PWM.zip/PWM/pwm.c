#include<reg51.h>
sbit glow=P1^1;
sbit glow2=P1^0;
void delay(int a)
{
	int i,j;
	
	for(i=0;i<a;i++)
	  for(j=0;j<5;j++);
 }
void main()
{
	int j,k,a=30;
while(1)
{
	for(j=0;j<=50;j++)
	{
	glow=1;
		for(k=0;k<=j;k++){delay(a);}
	glow=0;
		for(k=0;k<=j;k++){delay(a);}
	}
	a--;
	while(a>0);
}
}