#include <reg51.h>
#include <8digit_seven_seg.h>

int main()
{
	 
	while(1)
	{
		sendToseg(a);
	}
	 
}