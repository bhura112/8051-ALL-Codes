sbit SetButton=P1^0;
sbit HourButton=P1^1;
sbit MinButton=P1^2;
sbit SecButton=P1^3;
int k,l,m,n,o,p,q,click=0;
 char a[10]={0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x6f},i;
void delay(int time)
{
	int i,j;
	for(i=0;i<time;i++)
	  for(j=0;j<100;j++);
}

void seTseg(char *f)
     {
	        while(click==1){
						            if(SetButton==0){
													       click++;
													while(SetButton==0);
												}
												 if(HourButton==0){
													       l++;
													 if(l>9){
														 k++; l=0;}
													 if(k>1 && l>3){
														 k=0;l=0;}
													while(HourButton==0);
												}
												  if(MinButton==0){
													       n++;
														 if(m==5 && n==9){
														 m=0;n=0;l++;}
													 if(n>9){
														 m++; n=0;}
													while(MinButton==0);
												}
												
												 if(SecButton==0){
													       p++;
													 if(o==5 && p>9){
														 o=0;p=0;n++;}
													 if(p>9){
														 o++; p=0;}
													while(SecButton==0);
												}
											  
												if(click==2)
												{
													click=0;
												}
															 P3=~0x80;
															 P2=*(f+p);
															 delay(1);
															
						                   P3=~0x40;
															 P2=*(f+o);
															 delay(1);
															 
															 P3=~0x20;
															 P2=0x40;
															 delay(1);
						 
						                   P3=~0x10;
															 P2=*(f+n);
															 delay(1);
															
															 P3=~0x08;
															 P2=*(f+m);
															 delay(1);
											 
											         P3=~0x04;
															 P2=0x40;
															 delay(1);
						 
						                   P3=~0x02;
															 P2=*(f+l);
															 delay(1);
															
															 P3=~0x01;
															 P2=*(f+k);
															 delay(1);
				
			}
}
void sendToseg(char *f)
{
	     
	        for(k=0;k<2;k++){
					 for(l=0;l<10;l++) {
						 for(m=0;m<6;m++) {
							 for(n=0;n<10;n++) {
								 for(o=0;o<6;o++) {
									 for(p=0;p<10;p++) {
										 for(q=0;q<85;q++) {
															 P3=~0x80;
															 P2=*(f+p);
															 delay(1);
															
						                   P3=~0x40;
															 P2=*(f+o);
															 delay(1);
															 
															 P3=~0x20;
															 P2=0x40;
															 delay(1);
						 
						                   P3=~0x10;
															 P2=*(f+n);
															 delay(1);
															
															 P3=~0x08;
															 P2=*(f+m);
															 delay(1);
											 
											         P3=~0x04;
															 P2=0x40;
															 delay(1);
						 
						                   P3=~0x02;
															 P2=*(f+l);
															 delay(1);
															
															 P3=~0x01;
															 P2=*(f+k);
															 delay(1);
															 if(SetButton==0)
																	{
																		click++;
																		while(SetButton==0);
																	}
																	if(click==1)
																	{
																		seTseg(a);
																	}
				
			}}}}}}}
}