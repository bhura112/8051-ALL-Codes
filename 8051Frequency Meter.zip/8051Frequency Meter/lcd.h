sbit RS=P2^0;
sbit E=P2^1;
void delay(long int time)
{
	 int i,j;
	 for(i=0;i<time;i++)
	     for(j=0;j<950;j++);
}
void lcd_cmd(unsigned char x)
{
	    P1=x;
	    RS=0;
	    E=1;
	    delay(1);
	    E=0;
}

void lcd_data(unsigned char x)
{
	    P1=x;
	    RS=1;
	    E=1;
	    delay(1);
	    E=0;
}
void lcd_init(void)
{
	lcd_cmd(0x38);
	lcd_cmd(0x0e);
	lcd_cmd(0x06);
	lcd_cmd(0x80);
	lcd_cmd(0x01);
}
void lcd_clear()
{
	lcd_cmd(0x01);
}
void lcd_str(char *p)
{
	while(*p)
		lcd_data(*p++);
}