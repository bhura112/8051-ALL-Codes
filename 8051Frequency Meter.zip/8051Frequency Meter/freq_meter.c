#include <reg52.h>
#include <lcd.h>
#include <stdio.h>
char buff[30];
void delay_ms(int time)
{
	int i,j;
	for(i=0;i<time;i++)
	  for(j=0;j<1275;j++);
}
void main (void)
{
int a,a0,a1,a2,a3,b,step=0;
long float	 fReading=0,sReading=0,finalReading=0,z=0;
	lcd_init();
SCON  = 0x50;
TMOD |= 0x20;
TH1   = 0xFA;
TR1   = 1;
TI    = 1;
PCON |= 0x80;

printf ("\r\nCounter 0 Example\r\n");
printf ("\r\nPrint Frequency On Lcd\r\n\r\n");

TMOD = (TMOD & 0xF0) | 0x05;
TR0 = 1;
while (1)
  {
		for(z=0;z<3;z++)
  {
   a=TH0;
	 b=TL0;
		if(step==0)
		{
		  a0=a<<8|b;
		}
		if(step==1)
		{
			a1=a<<8|b;
		}
		if(step==2)
		{
			a2=a<<8|b;
		}
		delay_ms(133);
		step++;
		if(step>2)
		{
			step=0;
		}
	 }
	 lcd_clear();
	 fReading=a1-a0;
	 sReading=a2-a1;
	 finalReading=(fReading+sReading)/2;
	 
	 if(finalReading<1000)
	 {
	  sprintf(buff,"%f",finalReading);
	  lcd_str(buff);
          printf("FREQ : %s HZ\n",buff);
	  lcd_str("HZ");
	 }
	 
	  if(finalReading>1000 && finalReading <1000000)
	 {
		 finalReading=finalReading/1000;
	  sprintf(buff,"%f",finalReading);
	  lcd_str(buff);
          printf("FREQ : %s KHZ\n",buff);
	  lcd_str("KHZ");
	 }
	 
  }
}

