#include <reg51.h>

sbit LED = P1^0;    // give a name LED to PIN0 of port 1 
void delay(unsigned int time); // delay function
int main()
{

while(1)       //FOREVER LOOP
{
  LED = 0;     //LED OFF
  delay(100);  //DELAY
  LED = 1;     //LED ON
  delay(100);  //DELAY
}

}

void delay(unsigned int time)
{
  int i,j;
  for(i=0;i<time;i++)
    for(j=0;j<1275;j++);

}