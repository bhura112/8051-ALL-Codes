/*****************************lcd 16x2*******************************/
sbit rs=P3^0;
sbit e=P3^1;
void delay(int time)
{
   int i,j;
   for(i=0;i<time;i++)
      for(j=0;j<1275;j++);
}
void lcd_cmd(char x)
{
   P1=x;
   rs=0;
   e=1;
   delay(10);
   e=0;
}

void lcd_data(char x)
{
   P1=x;
   rs=1;
   e=1;
   delay(10);
   e=0;
}
void lcd_str(char *x)
{
char char_counter=0;
  while(*x)
  {
    lcd_data(*x++);
	if(16==char_counter++)
	    lcd_cmd(0x07);
	}
}
void lcd_clr()
{
  lcd_cmd(0x01);
}
void lcd_2Row()
  {
		 lcd_cmd(0xc0);
	}
/*void lcd_int(int x)
{
	  int a,i=0;
	   a=x;
	  while(x>9)
		{
			x=x/10;
			i++;
		}
}*/
void lcd_init()
{
  lcd_cmd(0x38);
  lcd_cmd(0x0e);
  //lcd_cmd(0x06);
  lcd_cmd(0x01);
  lcd_cmd(0x80);	
}
