#include <reg51.h>
#include <lcd_8bit.h>
#include <scan_keypad.h>


int main()
{
	char a[5];
	lcd_init();
	keypad_init();
while(1)	
{
   a[0]=getkey();
			 lcd_data(a[0]);
}
}